import { Component, OnInit } from '@angular/core';

import { Criminal } from './../../models/criminal';
import { CriminalService } from './../../services/criminal.service';

@Component({
  selector: 'app-criminals',
  templateUrl: './criminals.component.html',
  styleUrls: ['./criminals.component.css']
})
export class CriminalsComponent implements OnInit {
  criminals: Criminal[];

  constructor(private criminalService: CriminalService) { }

  ngOnInit() {
    this.getCriminals();
  }

  getCriminals(): void {
    this.criminalService.getCriminals()
    .subscribe(criminals => this.criminals = criminals);
  } 

  add(activity: string, lastName: string): void {
    lastName = lastName.trim();
    if (!lastName) { return; }
	
  this.criminalService.addCriminal({activity, lastName} as Criminal)
      .subscribe(
	  criminal => {this.criminals.push(criminal);}
	  );
  }

  delete(criminal: Criminal): void {
	this.criminals = this.criminals.filter(l => l !== criminal);
    this.criminalService.deleteCriminal(criminal).subscribe();
}

}

