import { Component, OnInit, Input } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Agent } from './../../models/agent';
import { AgentService } from './../../services/agent.service';

@Component({
  selector: 'app-agent-detail',
  templateUrl: './agent-detail.component.html',
  styleUrls: ['./agent-detail.component.css']
})
export class AgentDetailComponent implements OnInit {
 @Input() agent: Agent;

  constructor(
    private route: ActivatedRoute,
    private agentService: AgentService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.getAgent();
  }

  getAgent(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.agentService.getAgentById(id)
      .subscribe(agent => this.agent = agent);
  }

  goBack(): void {
    this.location.back();
  }

 save(): void {
    this.agentService.updateAgent(this.agent)
      .subscribe(() => this.goBack());
  }

}
