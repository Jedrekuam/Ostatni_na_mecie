import { Component, OnInit } from '@angular/core';

import { Section } from './../../models/section';
import { SectionService } from './../../services/section.service';

@Component({
  selector: 'app-sections',
  templateUrl: './sections.component.html',
  styleUrls: ['./sections.component.css']
})
export class SectionsComponent implements OnInit {
  sections: Section[];

  constructor(private sectionService: SectionService) { }

  ngOnInit() {
    this.getSections();
  }

  getSections(): void {
    this.sectionService.getSections()
    .subscribe(sections => this.sections = sections);
  } 

  add(name: string, activityType: string): void {
    name = name.trim();
    if (!name) { return; }
	
  this.sectionService.addSection({name, activityType} as Section)
      .subscribe(
	  section => {this.sections.push(section);}
	  );
  }

  delete(section: Section): void {
	this.sections = this.sections.filter(l => l !== section);
    this.sectionService.deleteSection(section).subscribe();
}

}