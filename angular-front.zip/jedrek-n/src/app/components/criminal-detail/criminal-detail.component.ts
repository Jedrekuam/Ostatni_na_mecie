import { Component, OnInit, Input } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Criminal } from './../../models/criminal';
import { CriminalService } from './../../services/criminal.service';

@Component({
  selector: 'app-criminal-detail',
  templateUrl: './criminal-detail.component.html',
  styleUrls: ['./criminal-detail.component.css']
})
export class CriminalDetailComponent implements OnInit {
 @Input() criminal: Criminal;

  constructor(
    private route: ActivatedRoute,
    private criminalService: CriminalService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.getCriminal();
  }

  getCriminal(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.criminalService.getCriminalById(id)
      .subscribe(criminal => this.criminal = criminal);
  }

  goBack(): void {
    this.location.back();
  }

 save(): void {
    this.criminalService.updateCriminal(this.criminal)
      .subscribe(() => this.goBack());
  }

}
