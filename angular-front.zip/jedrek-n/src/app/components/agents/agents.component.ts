import { Component, OnInit } from '@angular/core';

import { Agent } from './../../models/agent';
import { AgentService } from './../../services/agent.service';

@Component({
  selector: 'app-agents',
  templateUrl: './agents.component.html',
  styleUrls: ['./agents.component.css']
})
export class AgentsComponent implements OnInit {
  agents: Agent[];

  constructor(private agentService: AgentService) { }

  ngOnInit() {
    this.getAgents();
  }

  getAgents(): void {
    this.agentService.getAgents()
    .subscribe(agents => this.agents = agents);
  } 

  add(firstName: string, lastName: string): void {
    firstName = firstName.trim();
    if (!firstName) { return; }
	
  this.agentService.addAgent({firstName, lastName} as Agent)
      .subscribe(
	  agent => {this.agents.push(agent);}
	  );
  }

  delete(agent: Agent): void {
	this.agents = this.agents.filter(l => l !== agent);
    this.agentService.deleteAgent(agent).subscribe();
}

}

