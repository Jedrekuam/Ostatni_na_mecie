import { Component, OnInit, Input } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Section } from './../../models/section';
import { SectionService } from './../../services/section.service';

@Component({
  selector: 'app-section-detail',
  templateUrl: './section-detail.component.html',
  styleUrls: ['./section-detail.component.css']
})
export class SectionDetailComponent implements OnInit {
 @Input() section: Section;

  constructor(
    private route: ActivatedRoute,
    private sectionService: SectionService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.getSection();
  }

  getSection(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.sectionService.getSectionById(id)
      .subscribe(section => this.section = section);
  }

  goBack(): void {
    this.location.back();
  }

 save(): void {
    this.sectionService.updateSection(this.section)
      .subscribe(() => this.goBack());
  }

}

