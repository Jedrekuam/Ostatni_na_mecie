import { Component, OnInit } from '@angular/core';

import { Operation } from './../../models/operation';
import { OperationService } from './../../services/operation.service';

@Component({
  selector: 'app-operations',
  templateUrl: './operations.component.html',
  styleUrls: ['./operations.component.css']
})
export class OperationsComponent implements OnInit {
  operations: Operation[];

  constructor(private operationService: OperationService) { }

  ngOnInit() {
    this.getOperations();
  }

  getOperations(): void {
    this.operationService.getOperations()
    .subscribe(operations => this.operations = operations);
  } 

  add(goal: string, operationDate: Date): void {
    goal = goal.trim();
    if (!goal) { return; }
	
  this.operationService.addOperation({goal, operationDate} as Operation)
      .subscribe(
	  operation => {this.operations.push(operation);}
	  );
  }

  delete(operation: Operation): void {
	this.operations = this.operations.filter(l => l !== operation);
    this.operationService.deleteOperation(operation).subscribe();
}

}

