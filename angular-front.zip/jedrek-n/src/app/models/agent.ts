export class Agent {
	id: number;
	firstName: string;
	lastName: string;
}