export class Section {
	id: number;
	name: string;
	activityType: string;
}