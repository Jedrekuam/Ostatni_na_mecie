export class Criminal {
	id: number;
	lastName: string;
	activity: string;
}