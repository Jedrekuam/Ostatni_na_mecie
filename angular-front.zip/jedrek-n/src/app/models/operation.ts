export class Operation {
	id: number;
	goal: string;
	operationDate: Date;
}