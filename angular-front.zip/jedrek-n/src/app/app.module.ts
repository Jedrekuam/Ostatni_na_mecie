import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';


import { AppComponent } from './app.component';
import { AgentsComponent } from './components/agents/agents.component';
import { AgentService } from './services/agent.service';
import { MessageService } from './services/message.service';
import { MessagesComponent } from './components/messages/messages.component';
import { AppRoutingModule } from './app-routing.module';
import { CriminalsComponent } from './components/criminals/criminals.component';
import { SectionsComponent } from './components/sections/sections.component';
import { OperationsComponent } from './components/operations/operations.component';
import { SectionService } from './services/section.service';
import { OperationService } from './services/operation.service';
import { CriminalService } from './services/criminal.service';
import { AgentDetailComponent } from './components/agent-detail/agent-detail.component';
import { CriminalDetailComponent } from './components/criminal-detail/criminal-detail.component';
import { SectionDetailComponent } from './components/section-detail/section-detail.component';
import { OperationDetailComponent } from './components/operation-detail/operation-detail.component';


@NgModule({
  declarations: [
    AppComponent,
    AgentsComponent,
    MessagesComponent,
    CriminalsComponent,
    SectionsComponent,
    OperationsComponent,
    AgentDetailComponent,
    CriminalDetailComponent,
    SectionDetailComponent,
    OperationDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [AgentService, MessageService, SectionService, OperationService, CriminalService],
  bootstrap: [AppComponent]
})
export class AppModule { }
