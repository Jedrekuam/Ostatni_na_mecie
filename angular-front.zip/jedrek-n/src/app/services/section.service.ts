import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Section } from './../models/section';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'})
};

@Injectable()
export class SectionService {

  private sectionsUrl = 'http://localhost:8080/api/sections';  // URL to web api
  private sectionUrl = 'http://localhost:8080/api/section';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getSections (): Observable<Section[]> {
    return this.http.get<Section[]>(this.sectionsUrl)
      .pipe(
        tap(sections => this.log(`fetched sections`)),
        catchError(this.handleError('getSections', []))
      );
  }

  getSectionNo404<Data>(id: number): Observable<Section> {
    const url = `${this.sectionsUrl}/?id=${id}`;
    return this.http.get<Section[]>(url)
      .pipe(
        map(sections => sections[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.log(`${outcome} section id=${id}`);
        }),
        catchError(this.handleError<Section>(`getSection id=${id}`))
      );
  }

  getSectionById(id: number): Observable<Section> {
    const url = `${this.sectionsUrl}/${id}`;
    return this.http.get<Section>(url).pipe(
      tap(_ => this.log(`fetched sections id=${id}`)),
      catchError(this.handleError<Section>(`getSection id=${id}`))
    );
  }


  addSection (section: Section): Observable<Section> {
    return this.http.post<Section>(this.sectionUrl, section, httpOptions).pipe(
      tap((section: Section) => this.log(`added section w/ id=${section.id}`)),
      catchError(this.handleError<Section>('addSection'))
    );
  }

  deleteSection (section: Section | number): Observable<Section> {
    const id = typeof section === 'number' ? section : section.id;
    const url = `${this.sectionsUrl}/${id}`;

    return this.http.delete<Section>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted section id=${id}`)),
      catchError(this.handleError<Section>('deleteSection'))
    );
  }

  updateSection (section: Section): Observable<any> {
    return this.http.put(this.sectionUrl, section, httpOptions).pipe(
      tap(_ => this.log(`updated section id=${section.id}`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }
  
  
  countSections(): Observable<number> {
	  const url = this.sectionsUrl + '/number';
		return this.http.get<number>(url);
  }
  

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
		
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
    this.messageService.add('SectionService: ' + message);
  }
}
