import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Criminal } from './../models/criminal';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'})
};

@Injectable()
export class CriminalService {

  private criminalsUrl = 'http://localhost:8080/api/criminals';  // URL to web api
  private criminalUrl = 'http://localhost:8080/api/criminal';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getCriminals (): Observable<Criminal[]> {
    return this.http.get<Criminal[]>(this.criminalsUrl)
      .pipe(
        tap(criminals => this.log(`fetched criminals`)),
        catchError(this.handleError('getCriminals', []))
      );
  }

  getCriminalNo404<Data>(id: number): Observable<Criminal> {
    const url = `${this.criminalsUrl}/?id=${id}`;
    return this.http.get<Criminal[]>(url)
      .pipe(
        map(criminals => criminals[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.log(`${outcome} criminal id=${id}`);
        }),
        catchError(this.handleError<Criminal>(`getCriminal id=${id}`))
      );
  }

  getCriminalById(id: number): Observable<Criminal> {
    const url = `${this.criminalsUrl}/${id}`;
    return this.http.get<Criminal>(url).pipe(
      tap(_ => this.log(`fetched criminals id=${id}`)),
      catchError(this.handleError<Criminal>(`getCriminal id=${id}`))
    );
  }


  addCriminal (criminal: Criminal): Observable<Criminal> {
    return this.http.post<Criminal>(this.criminalUrl, criminal, httpOptions).pipe(
      tap((criminal: Criminal) => this.log(`added criminal w/ id=${criminal.id}`)),
      catchError(this.handleError<Criminal>('addCriminal'))
    );
  }

  deleteCriminal (criminal: Criminal | number): Observable<Criminal> {
    const id = typeof criminal === 'number' ? criminal : criminal.id;
    const url = `${this.criminalsUrl}/${id}`;

    return this.http.delete<Criminal>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted criminal id=${id}`)),
      catchError(this.handleError<Criminal>('deleteCriminal'))
    );
  }

  updateCriminal (criminal: Criminal): Observable<any> {
    return this.http.put(this.criminalUrl, criminal, httpOptions).pipe(
      tap(_ => this.log(`updated criminal id=${criminal.id}`)),
      catchError(this.handleError<any>('updateCriminal'))
    );
  }
  
  
  countCriminals(): Observable<number> {
	  const url = this.criminalsUrl + '/number';
		return this.http.get<number>(url);
  }
  

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
		
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
    this.messageService.add('CriminalService: ' + message);
  }
}
