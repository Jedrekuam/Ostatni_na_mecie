import { TestBed, inject } from '@angular/core/testing';

import { CriminalService } from './criminal.service';

describe('CriminalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CriminalService]
    });
  });

  it('should be created', inject([CriminalService], (service: CriminalService) => {
    expect(service).toBeTruthy();
  }));
});
