import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Operation } from './../models/operation';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'})
};

@Injectable()
export class OperationService {

  private operationsUrl = 'http://localhost:8080/api/operations';  // URL to web api
  private operationUrl = 'http://localhost:8080/api/operation';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getOperations (): Observable<Operation[]> {
    return this.http.get<Operation[]>(this.operationsUrl)
      .pipe(
        tap(operations => this.log(`fetched operations`)),
        catchError(this.handleError('getOperations', []))
      );
  }

  getOperationNo404<Data>(id: number): Observable<Operation> {
    const url = `${this.operationsUrl}/?id=${id}`;
    return this.http.get<Operation[]>(url)
      .pipe(
        map(operations => operations[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.log(`${outcome} agent id=${id}`);
        }),
        catchError(this.handleError<Operation>(`getOperation id=${id}`))
      );
  }

  getOperationById(id: number): Observable<Operation> {
    const url = `${this.operationsUrl}/${id}`;
    return this.http.get<Operation>(url).pipe(
      tap(_ => this.log(`fetched operations id=${id}`)),
      catchError(this.handleError<Operation>(`getOperation id=${id}`))
    );
  }


  addOperation (operation: Operation): Observable<Operation> {
    return this.http.post<Operation>(this.operationUrl, operation, httpOptions).pipe(
      tap((operation: Operation) => this.log(`added operation w/ id=${operation.id}`)),
      catchError(this.handleError<Operation>('addOperation'))
    );
  }

  deleteOperation (operation: Operation | number): Observable<Operation> {
    const id = typeof operation === 'number' ? operation : operation.id;
    const url = `${this.operationsUrl}/${id}`;

    return this.http.delete<Operation>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted operation id=${id}`)),
      catchError(this.handleError<Operation>('deleteOperation'))
    );
  }

  updateOperation (operation: Operation): Observable<any> {
    return this.http.put(this.operationUrl, operation, httpOptions).pipe(
      tap(_ => this.log(`updated operation id=${operation.id}`)),
      catchError(this.handleError<any>('updateOperation'))
    );
  }
  
  
  countOperations(): Observable<number> {
	  const url = this.operationsUrl + '/number';
		return this.http.get<number>(url);
  }
  

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
		
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
    this.messageService.add('OperationService: ' + message);
  }
}
