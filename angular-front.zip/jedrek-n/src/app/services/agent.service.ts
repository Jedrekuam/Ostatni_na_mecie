import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Agent } from './../models/agent';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'})
};

@Injectable()
export class AgentService {

  private agentsUrl = 'http://localhost:8080/api/agents';  // URL to web api
  private agentUrl = 'http://localhost:8080/api/agent';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getAgents (): Observable<Agent[]> {
    return this.http.get<Agent[]>(this.agentsUrl)
      .pipe(
        tap(agents => this.log(`fetched agents`)),
        catchError(this.handleError('getAgents', []))
      );
  }

  getAgentNo404<Data>(id: number): Observable<Agent> {
    const url = `${this.agentsUrl}/?id=${id}`;
    return this.http.get<Agent[]>(url)
      .pipe(
        map(agents => agents[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.log(`${outcome} agent id=${id}`);
        }),
        catchError(this.handleError<Agent>(`getAgent id=${id}`))
      );
  }

  getAgentById(id: number): Observable<Agent> {
    const url = `${this.agentsUrl}/${id}`;
    return this.http.get<Agent>(url).pipe(
      tap(_ => this.log(`fetched agents id=${id}`)),
      catchError(this.handleError<Agent>(`getAgent id=${id}`))
    );
  }

  searchAgents(term: string): Observable<Agent[]> {
    if (!term.trim()) {
      // if not search term, return empty agent array.
      return of([]);
    }
		
    return this.http.get<Agent[]>(`${this.agentUrl}/?name=${term}`).pipe(
      tap(_ => this.log(`found agents matching "${term}"`)),
      catchError(this.handleError<Agent[]>('searchAgents', []))
    );
  }


  addAgent (agent: Agent): Observable<Agent> {
    return this.http.post<Agent>(this.agentUrl, agent, httpOptions).pipe(
      tap((agent: Agent) => this.log(`added agent w/ id=${agent.id}`)),
      catchError(this.handleError<Agent>('addAgent'))
    );
  }

  deleteAgent (agent: Agent | number): Observable<Agent> {
    const id = typeof agent === 'number' ? agent : agent.id;
    const url = `${this.agentsUrl}/${id}`;

    return this.http.delete<Agent>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted agent id=${id}`)),
      catchError(this.handleError<Agent>('deleteAgent'))
    );
  }

  updateAgent (agent: Agent): Observable<any> {
    return this.http.put(this.agentUrl, agent, httpOptions).pipe(
      tap(_ => this.log(`updated agent id=${agent.id}`)),
      catchError(this.handleError<any>('updateAgent'))
    );
  }
  
  
  countAgents(): Observable<number> {
	  const url = this.agentsUrl + '/number';
		return this.http.get<number>(url);
  }
  

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
		
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
    this.messageService.add('AgentService: ' + message);
  }
}
