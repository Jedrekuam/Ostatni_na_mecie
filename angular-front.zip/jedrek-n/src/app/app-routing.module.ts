import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AgentsComponent } from './components/agents/agents.component';
import { CriminalsComponent } from './components/criminals/criminals.component';
import { SectionsComponent } from './components/sections/sections.component';
import { OperationsComponent } from './components/operations/operations.component';

import { AgentDetailComponent } from './components/agent-detail/agent-detail.component';
import { CriminalDetailComponent } from './components/criminal-detail/criminal-detail.component';
import { SectionDetailComponent } from './components/section-detail/section-detail.component';
import { OperationDetailComponent } from './components/operation-detail/operation-detail.component';



const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'agents', component: AgentsComponent },
  { path: 'criminals', component: CriminalsComponent },
  { path: 'sections', component: SectionsComponent },
  { path: 'operations', component: OperationsComponent },
  { path: 'agent-detail/:id', component: AgentDetailComponent },
  { path: 'criminal-detail/:id', component: CriminalDetailComponent },
  { path: 'section-detail/:id', component: SectionDetailComponent },
  { path: 'operation-detail/:id', component: OperationDetailComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
